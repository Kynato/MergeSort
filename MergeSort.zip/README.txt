Dzień dobry :)

Sam MergeSort znajduje się w pliku fx.hpp

Rozmiar losowania, ilość podziałów i ilość prób do średniej można zmieniać w main.cpp

Generalnie to zdaje się być poprawne chociaż nie wiem co myśleć o wykresie czasu wykonania w zależności od ilości podziałów.

Z poważaniem,
Alan Hudela